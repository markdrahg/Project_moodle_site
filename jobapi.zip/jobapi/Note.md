## Setting up the job plugin in moodle

## using local host for the setup

Note: This process is not stciked to local host only, the same process can be used for a hosted Moodle application inclusive

- step 1: Install the JobAPI plugin zip file

- step 2: enter this url in your Moodle app and have something like this;
  http://localhost/moodle/local/jobapi/
  Link this url to a Moodle url activity.
  Note: It redirect's user to the job listing page(index.php)

- step 3: enter this url in your Moodle app and have something like this;
  http://localhost/moodle/local/jobapi/Jobs_And_Applicants_Control.php
  Link this url to a Moodle url activity.
  Note: It redirect's user to the Jobs And Applicants Control page(Admin page)
